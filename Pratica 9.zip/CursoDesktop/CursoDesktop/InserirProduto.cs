﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AcessoDados;
using System.Data.SqlClient;

namespace CursoDesktop
{
    public partial class InserirProduto : Form
    {
        public InserirProduto()
        {
            InitializeComponent();
        }

        public InserirProduto(int id)
        {
            InitializeComponent();
            using (var context = new cursonetEntities())
            {
                produto produto = context.produto.Where(c => c.id == id).First();
                txtDescricao.Text = produto.descricao;
                txtCodigo.Text = produto.id.ToString();
                nuValor.Value = produto.valor;
                cbFabricante.Text = produto.fabricante;
            }
        }

        private void lblIdade_Click(object sender, EventArgs e)
        {

        }

        private void btSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                using (var context = new cursonetEntities())
                {
                    produto produto;
                    if (txtCodigo.Text == "")
                    {
                        produto = new produto();
                    }
                    else
                    {
                        int id = Convert.ToInt32(txtCodigo.Text);
                        produto = context.produto.Where(c => c.id == id).First();
                    }
                    produto.descricao = txtDescricao.Text.Trim();
                    produto.valor = nuValor.Value;
                    produto.fabricante = cbFabricante.Text.Trim();
                    if (txtCodigo.Text == "")
                    {
                        context.produto.Add(produto);
                    }
                    context.SaveChanges();
                }
                MessageBox.Show("Produto Cadastrado com Sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar produto!");
            }
        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            txtDescricao.Text = "";
            nuValor.Value = 0;
            cbFabricante.SelectedItem = 0;
        }
    }
}
