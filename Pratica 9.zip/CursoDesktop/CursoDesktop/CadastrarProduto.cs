﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CursoDesktop
{
    public partial class CadastrarProduto : Form
    {
        public CadastrarProduto()
        {
            InitializeComponent();
        }

        private void btNovo_Click(object sender, EventArgs e)
        {
            InserirProduto formInserirProduto = new InserirProduto();
            formInserirProduto.MdiParent = this.MdiParent;
            formInserirProduto.Show();
        }

        private void btLimpar_Click(object sender, EventArgs e)
        {
            txtDescricao.Text = "";
        }

        private void btConsultar_Click(object sender, EventArgs e)
        {
            using (var context = new cursonetEntities())
            {
                var dados = (from l in context.produto
                             where ((l.descricao.Contains(txtDescricao.Text.Trim()) || txtDescricao.Text.Trim().Equals("")) 
                            )
                             select new
                             {
                                 l.id,
                                 l.descricao,
                                 l.valor,
                                 l.fabricante
                             }).ToList();

                gwProduto.DataSource = dados;
            }
        }

        private void btRemover_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = gwProduto.CurrentRow;
            if (!string.IsNullOrEmpty(row.Cells[1].Value.ToString()))
            {
                int id = Convert.ToInt32(row.Cells[0].Value.ToString());
                using (var context = new cursonetEntities())
                {
                    produto produto = context.produto.Where(c => c.id == id).First();
                    context.produto.Remove(produto);
                    context.SaveChanges();
                }
            }
            btConsultar_Click(sender, e);
            MessageBox.Show("Cliente removido com sucesso!");
        }

        private void btAlterar_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = gwProduto.CurrentRow;
            try
            {
                if (!string.IsNullOrEmpty(row.Cells[1].Value.ToString()))
                {
                    int id = Convert.ToInt32(row.Cells[0].Value.ToString());
                    InserirProduto formInserirProduto = new InserirProduto(id);
                    formInserirProduto.MdiParent = this.MdiParent;
                    formInserirProduto.Show();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Erro ao alterar Cliente");
                throw;
            }
        }
    }
}
